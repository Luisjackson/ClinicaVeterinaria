import java.util.ArrayList;

public class Tutor extends Pessoa{
    private ArrayList<Animal> animais;
    String endereco;
    public Tutor(String nome, String cpf, String email, String endereco, String telefone){
        super(nome, cpf, email, telefone);
        this.endereco = endereco;
        this.animais = new ArrayList<Animal>();
    }
}