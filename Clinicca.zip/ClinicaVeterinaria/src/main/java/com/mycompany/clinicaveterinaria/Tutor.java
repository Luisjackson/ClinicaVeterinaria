
package com.mycompany.clinicaveterinaria;

import java.util.ArrayList;

public class Tutor extends Pessoa{
    private ArrayList<Animal> animais;
    private String endereco;

    public Tutor(String nome, String cpf, String email, String endereco, String telefone){
        super(nome, cpf, email, telefone);
        this.endereco = endereco;
        this.animais = new ArrayList<Animal>();
    }

    /**
     * @return the animais
     */
    public ArrayList<Animal> getAnimais() {
        return animais;
    }

    /**
     * @param animais the animais to set
     */
    public void setAnimais(ArrayList<Animal> animais) {
        this.animais = animais;
    }

    /**
     * @return the endereco
     */
    public String getEndereco() {
        return endereco;
    }

    /**
     * @param endereco the endereco to set
     */
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    
    
    
}
